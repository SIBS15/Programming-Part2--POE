using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[Route("api")]
public class ResultsController(RaceDayDbContext db) : ApiControllerBase(db)
{
    [HttpPost("enrolments/{enrolmentId:int}/results")] public async Task<IActionResult> Create(int enrolmentId,CreateResultRequest request)
    {var role=RequireRole("Organiser");if(role is not null)return role;if(request.FinishTime<TimeSpan.Zero||request.FinishPosition<=0)return BadRequest(new{message="Finish time must not be negative and finishing position must be greater than zero."});var e=await Db.Enrolments.Include(x=>x.Event).SingleOrDefaultAsync(x=>x.EnrolmentId==enrolmentId);if(e is null)return NotFound();if(e.Event!.OrganiserId!=CurrentUserId)return Forbid();if(await Db.Results.AnyAsync(r=>r.EnrolmentId==enrolmentId))return Conflict(new{message="A result already exists for this enrolment."});var result=new RaceResult{EnrolmentId=enrolmentId,FinishTime=request.FinishTime,FinishPosition=request.FinishPosition,CapturedByOrganiserId=CurrentUserId!.Value};Db.Results.Add(result);await Db.SaveChangesAsync();return StatusCode(201,result);}
    [HttpPut("results/{id:int}")] public async Task<IActionResult> Update(int id,UpdateResultRequest request)
    {var role=RequireRole("Organiser");if(role is not null)return role;if(request.FinishTime<TimeSpan.Zero||request.FinishPosition<=0)return BadRequest();var r=await Db.Results.Include(x=>x.Enrolment).ThenInclude(x=>x!.Event).SingleOrDefaultAsync(x=>x.ResultId==id);if(r is null)return NotFound();if(r.Enrolment!.Event!.OrganiserId!=CurrentUserId)return Forbid();r.FinishTime=request.FinishTime;r.FinishPosition=request.FinishPosition;r.RecordedAt=DateTime.UtcNow;await Db.SaveChangesAsync();return Ok(r);}
    [HttpGet("results/me")] public async Task<IActionResult> Mine()
    {var role=RequireRole("Participant");if(role is not null)return role;return Ok(await Db.Results.AsNoTracking().Where(r=>r.Enrolment!.ParticipantId==CurrentUserId).Select(r=>new{r.ResultId,r.EnrolmentId,r.FinishTime,r.FinishPosition,r.RecordedAt,EventName=r.Enrolment!.Event!.EventName,EventDate=r.Enrolment.Event!.EventDate,CategoryName=r.Enrolment.Category!.CategoryName}).OrderBy(r=>r.EventDate).ToListAsync());}
    [HttpGet("events/{eventId:int}/results")] public async Task<IActionResult> ForEvent(int eventId)
    {var role=RequireRole("Organiser");if(role is not null)return role;if(!await OwnsEvent(eventId))return NotFound(new{message="Event not found or not owned by this organiser."});return Ok(await Db.Results.AsNoTracking().Where(r=>r.Enrolment!.EventId==eventId).Select(r=>new{r.ResultId,r.EnrolmentId,r.FinishTime,r.FinishPosition,ParticipantName=r.Enrolment!.Participant!.FirstName+" "+r.Enrolment.Participant.LastName,CategoryName=r.Enrolment.Category!.CategoryName}).OrderBy(r=>r.FinishPosition).ToListAsync());}
}