using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[Route("api")]
public class EnrolmentsController(RaceDayDbContext db) : ApiControllerBase(db)
{
    [HttpPost("enrolments")] public async Task<IActionResult> Create(CreateEnrolmentRequest request)
    {
        var role=RequireRole("Participant");if(role is not null)return role;
        var ev=await Db.Events.FindAsync(request.EventId);var cat=await Db.Categories.FindAsync(request.CategoryId);if(ev is null||cat is null||cat.EventId!=request.EventId)return NotFound(new{message="Event or matching category was not found."});
        if(ev.EventDate<DateTime.UtcNow.Date)return BadRequest(new{message="You cannot enrol in an event that has already taken place."});
        if(await Db.Enrolments.AnyAsync(e=>e.ParticipantId==CurrentUserId&&e.EventId==request.EventId))return Conflict(new{message="You are already enrolled in this event."});
        if(await Db.Enrolments.CountAsync(e=>e.CategoryId==cat.CategoryId)>=cat.MaxParticipants)return Conflict(new{message="This category is full."});
        var enrolment=new Enrolment{ParticipantId=CurrentUserId!.Value,EventId=request.EventId,CategoryId=request.CategoryId};Db.Enrolments.Add(enrolment);await Db.SaveChangesAsync();return StatusCode(201,new{enrolment.EnrolmentId,enrolment.ParticipantId,enrolment.EventId,enrolment.CategoryId,enrolment.Status,enrolment.EnrolledAt});
    }
    [HttpGet("enrolments/me")] public async Task<IActionResult> Mine()
    {var role=RequireRole("Participant");if(role is not null)return role;return Ok(await Db.Enrolments.AsNoTracking().Where(e=>e.ParticipantId==CurrentUserId).Select(e=>new{e.EnrolmentId,e.EventId,EventName=e.Event!.EventName,e.CategoryId,CategoryName=e.Category!.CategoryName,e.Status,e.EnrolledAt}).ToListAsync());}
    [HttpGet("events/{eventId:int}/enrolments")] public async Task<IActionResult> ForEvent(int eventId)
    {var role=RequireRole("Organiser");if(role is not null)return role;if(!await OwnsEvent(eventId))return NotFound(new{message="Event not found or not owned by this organiser."});return Ok(await Db.Enrolments.AsNoTracking().Where(e=>e.EventId==eventId).Select(e=>new{e.EnrolmentId,e.ParticipantId,ParticipantName=e.Participant!.FirstName+" "+e.Participant.LastName,e.CategoryId,CategoryName=e.Category!.CategoryName,e.Status,e.EnrolledAt}).ToListAsync());}
    [HttpDelete("enrolments/{id:int}")] public async Task<IActionResult> Cancel(int id)
    {var role=RequireRole("Participant");if(role is not null)return role;var e=await Db.Enrolments.FindAsync(id);if(e is null)return NotFound();if(e.ParticipantId!=CurrentUserId)return Forbid();if(await Db.Results.AnyAsync(r=>r.EnrolmentId==id))return Conflict(new{message="An enrolment with a result cannot be cancelled."});Db.Enrolments.Remove(e);await Db.SaveChangesAsync();return NoContent();}
}