using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[Route("api/auth")]
public class AuthController(RaceDayDbContext db) : ApiControllerBase(db)
{
    private readonly PasswordHasher<AppUser> _hasher = new();
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        if (request.Role is not ("Organiser" or "Participant")) return BadRequest(new { message = "Role must be Organiser or Participant." });
        var email = request.Email.Trim().ToLowerInvariant();
        if (await Db.Users.AnyAsync(u => u.Email == email)) return Conflict(new { message = "Email is already registered." });
        var user = new AppUser { FirstName=request.FirstName.Trim(), LastName=request.LastName.Trim(), Email=email, Role=request.Role };
        user.PasswordHash = _hasher.HashPassword(user, request.Password);
        Db.Users.Add(user); await Db.SaveChangesAsync();
        return StatusCode(201, new { user.UserId, user.FirstName, user.LastName, user.Email, user.Role });
    }
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await Db.Users.SingleOrDefaultAsync(u => u.Email == email);
        if (user is null || _hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password) == PasswordVerificationResult.Failed)
            return Unauthorized(new { message = "Email or password is incorrect." });
        HttpContext.Session.Clear();
        HttpContext.Session.SetInt32("UserId", user.UserId);
        HttpContext.Session.SetString("Role", user.Role);
        HttpContext.Session.SetString("Email", user.Email);
        return Ok(new { message="Login successful. Session cookie has been set.", user.UserId, user.FirstName, user.LastName, user.Email, user.Role });
    }
    [HttpPost("logout")]
    public IActionResult Logout() { HttpContext.Session.Clear(); return Ok(new { message = "You have been logged out." }); }
}