using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[ApiController]
public abstract class ApiControllerBase(RaceDayDbContext db) : ControllerBase
{
    protected readonly RaceDayDbContext Db = db;
    protected int? CurrentUserId => HttpContext.Session.GetInt32("UserId");
    protected string? CurrentRole => HttpContext.Session.GetString("Role");
    protected bool IsSignedIn => CurrentUserId.HasValue && !string.IsNullOrWhiteSpace(CurrentRole);
    protected IActionResult? RequireRole(string role)
    {
        if (!IsSignedIn) return Unauthorized(new { message = "Please log in first." });
        if (!string.Equals(CurrentRole, role, StringComparison.OrdinalIgnoreCase)) return Forbid();
        return null;
    }
    protected async Task<bool> OwnsEvent(int eventId)
        => await Db.Events.AnyAsync(e => e.EventId == eventId && e.OrganiserId == CurrentUserId);
}