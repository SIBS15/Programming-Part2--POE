using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[Route("api")]
public class CategoriesController(RaceDayDbContext db) : ApiControllerBase(db)
{
    [HttpGet("events/{eventId:int}/categories")] public async Task<IActionResult> ForEvent(int eventId)
    { if(!await Db.Events.AnyAsync(e=>e.EventId==eventId))return NotFound();return Ok(await Db.Categories.AsNoTracking().Where(c=>c.EventId==eventId).Select(c=>new{c.CategoryId,c.EventId,c.CategoryName,c.CategoryDistance,c.MaxParticipants}).ToListAsync()); }
    [HttpPost("events/{eventId:int}/categories")] public async Task<IActionResult> Create(int eventId,CreateCategoryRequest request)
    { var role=RequireRole("Organiser");if(role is not null)return role;if(!await OwnsEvent(eventId))return NotFound(new{message="Event not found or not owned by this organiser."});if(request.MaxParticipants is null or <= 0 || request.CategoryDistance is null or <= 0)return BadRequest(new{message="Category distance and maximum participants are required and must be positive."});var c=new Category{EventId=eventId,CategoryName=request.CategoryName.Trim(),CategoryDistance=request.CategoryDistance.Value,MaxParticipants=request.MaxParticipants.Value};Db.Categories.Add(c);await Db.SaveChangesAsync();return StatusCode(201,c); }
    [HttpPut("categories/{id:int}")] public async Task<IActionResult> Update(int id,CreateCategoryRequest request)
    { var role=RequireRole("Organiser");if(role is not null)return role;var c=await Db.Categories.Include(x=>x.Event).SingleOrDefaultAsync(x=>x.CategoryId==id);if(c is null)return NotFound();if(c.Event!.OrganiserId!=CurrentUserId)return Forbid();if(request.MaxParticipants is null or <= 0 || request.CategoryDistance is null or <= 0)return BadRequest(new{message="Category distance and maximum participants are required and must be positive."});c.CategoryName=request.CategoryName.Trim();c.CategoryDistance=request.CategoryDistance.Value;c.MaxParticipants=request.MaxParticipants.Value;await Db.SaveChangesAsync();return Ok(c); }
    [HttpDelete("categories/{id:int}")] public async Task<IActionResult> Delete(int id)
    { var role=RequireRole("Organiser");if(role is not null)return role;var c=await Db.Categories.Include(x=>x.Event).Include(x=>x.Enrolments).SingleOrDefaultAsync(x=>x.CategoryId==id);if(c is null)return NotFound();if(c.Event!.OrganiserId!=CurrentUserId)return Forbid();if(c.Enrolments.Count>0)return Conflict(new{message="Category has enrolments and cannot be deleted."});Db.Categories.Remove(c);await Db.SaveChangesAsync();return NoContent(); }
}