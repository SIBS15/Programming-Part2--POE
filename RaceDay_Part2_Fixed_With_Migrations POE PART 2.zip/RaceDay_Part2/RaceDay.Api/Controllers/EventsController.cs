using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[Route("api/events")]
public class EventsController(RaceDayDbContext db) : ApiControllerBase(db)
{
    [HttpGet] public async Task<IActionResult> All() => Ok(await Db.Events.AsNoTracking().OrderBy(e=>e.EventDate).Select(e=>new { e.EventId,e.EventName,e.Description,e.EventDate,e.Location,e.Distance,e.EventType,e.OrganiserId }).ToListAsync());
    [HttpGet("{id:int}")] public async Task<IActionResult> One(int id) { var e=await Db.Events.AsNoTracking().Where(x=>x.EventId==id).Select(x=>new { x.EventId,x.EventName,x.Description,x.EventDate,x.Location,x.Distance,x.EventType,x.OrganiserId }).SingleOrDefaultAsync(); return e is null?NotFound():Ok(e); }
    [HttpPost] public async Task<IActionResult> Create(CreateEventRequest request)
    {
        var role=RequireRole("Organiser"); if(role is not null)return role;
        if(request.EventDate < DateTime.UtcNow.Date || request.Distance <= 0 || !new[]{"Running","Walking","Cycling"}.Contains(request.EventType)) return BadRequest(new { message="Use a future/current date, positive distance, and event type Running, Walking, or Cycling." });
        var e=new RaceEvent { EventName=request.EventName.Trim(),Description=request.Description??"",EventDate=request.EventDate,Location=request.Location.Trim(),Distance=request.Distance,EventType=request.EventType,OrganiserId=CurrentUserId!.Value };
        Db.Events.Add(e); await Db.SaveChangesAsync(); return CreatedAtAction(nameof(One),new{id=e.EventId},e);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, CreateEventRequest request)
    {
        var role=RequireRole("Organiser"); if(role is not null)return role;
        var e=await Db.Events.FindAsync(id); if(e is null)return NotFound(); if(e.OrganiserId!=CurrentUserId)return Forbid();
        if(request.Distance<=0 || !new[]{"Running","Walking","Cycling"}.Contains(request.EventType))return BadRequest(new{message="Distance must be positive and event type must be run, walk, or cycle."});
        e.EventName=request.EventName.Trim();e.Description=request.Description??"";e.EventDate=request.EventDate;e.Location=request.Location.Trim();e.Distance=request.Distance;e.EventType=request.EventType;await Db.SaveChangesAsync();return Ok(e);
    }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id)
    {
        var role=RequireRole("Organiser"); if(role is not null)return role;
        var e=await Db.Events.Include(x=>x.Enrolments).ThenInclude(x=>x.Result).Include(x=>x.Categories).SingleOrDefaultAsync(x=>x.EventId==id);if(e is null)return NotFound();if(e.OrganiserId!=CurrentUserId)return Forbid();
        if(e.Enrolments.Any(x=>x.Result is not null))return Conflict(new{message="An event with recorded results cannot be deleted."});
        Db.Events.Remove(e);await Db.SaveChangesAsync();return NoContent();
    }
}