using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
namespace RaceDay.Api.Controllers;
[Route("api/users")]
public class UsersController(RaceDayDbContext db) : ApiControllerBase(db)
{
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        if (!IsSignedIn) return Unauthorized();
        var user = await Db.Users.Where(u => u.UserId == CurrentUserId).Select(u => new { u.UserId,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.CreatedAt }).SingleOrDefaultAsync();
        return user is null ? NotFound() : Ok(user);
    }
    [HttpPut("me")]
    public async Task<IActionResult> UpdateMe(UpdateProfileRequest request)
    {
        if (!IsSignedIn) return Unauthorized();
        var user = await Db.Users.FindAsync(CurrentUserId!.Value); if (user is null) return NotFound();
        user.FirstName=request.FirstName.Trim(); user.LastName=request.LastName.Trim(); user.PhoneNumber=request.PhoneNumber?.Trim();
        await Db.SaveChangesAsync();
        return Ok(new { user.UserId,user.FirstName,user.LastName,user.Email,user.Role,user.PhoneNumber });
    }
}