using System.ComponentModel.DataAnnotations;
namespace RaceDay.Api.Models;
public class RaceEvent
{
    public int EventId { get; set; }
    [Required, MaxLength(100)] public string EventName { get; set; } = "";
    [MaxLength(500)] public string? Description { get; set; }
    public DateTime EventDate { get; set; }
    [Required, MaxLength(150)] public string Location { get; set; } = "";
    public decimal? Distance { get; set; }
    [Required, MaxLength(20)] public string EventType { get; set; } = "Running";
    public int OrganiserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public AppUser? Organiser { get; set; }
    public ICollection<Category> Categories { get; set; } = new List<Category>();
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}
