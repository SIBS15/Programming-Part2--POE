using System.ComponentModel.DataAnnotations;
namespace RaceDay.Api.Models;
public class Enrolment
{
    public int EnrolmentId { get; set; }
    public int ParticipantId { get; set; }
    public AppUser? Participant { get; set; }
    public int EventId { get; set; }
    public RaceEvent? Event { get; set; }
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
    public DateTime EnrolledAt { get; set; } = DateTime.Now;
    [Required, MaxLength(20)] public string Status { get; set; } = "Confirmed";
    public RaceResult? Result { get; set; }
    public Payment? Payment { get; set; }
}
