using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Infrastructure;
using RaceDay.Api.Data;

#nullable disable

namespace RaceDay.Api.Migrations;

[DbContext(typeof(RaceDayDbContext))]
[Migration("20261014090000_InitialRaceDayDatabase")]
public partial class InitialRaceDayDatabase : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Users",
            columns: table => new
            {
                UserID = table.Column<int>(type: "int", nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                Role = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false),
                FirstName = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
                LastName = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
                Email = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                PasswordHash = table.Column<string>(type: "varchar(255)", maxLength: 255, nullable: false),
                PhoneNumber = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: true),
                CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(GETDATE())")
            }, constraints: table =>
            {
                table.PrimaryKey("PK_Users", x => x.UserID);
                table.CheckConstraint("CK_Users_Role", "[Role] IN ('Organiser','Participant')");
            });

        migrationBuilder.CreateTable(
            name: "Events",
            columns: table => new
            {
                EventID = table.Column<int>(type: "int", nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                OrganiserID = table.Column<int>(type: "int", nullable: false),
                EventName = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
                EventDate = table.Column<DateTime>(type: "date", nullable: false),
                Location = table.Column<string>(type: "varchar(150)", maxLength: 150, nullable: false),
                Distance = table.Column<decimal>(type: "decimal(6,2)", precision: 6, scale: 2, nullable: true),
                EventType = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false),
                CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(GETDATE())")
            }, constraints: table =>
            {
                table.PrimaryKey("PK_Events", x => x.EventID);
                table.CheckConstraint("CK_Events_EventType", "[EventType] IN ('Running','Walking','Cycling')");
                table.ForeignKey("FK_Events_Users_OrganiserID", x => x.OrganiserID, "Users", "UserID", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "Categories",
            columns: table => new
            {
                CategoryID = table.Column<int>(type: "int", nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                EventID = table.Column<int>(type: "int", nullable: false),
                CategoryName = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false),
                CategoryDistance = table.Column<decimal>(type: "decimal(6,2)", precision: 6, scale: 2, nullable: false),
                MaxParticipants = table.Column<int>(type: "int", nullable: false, defaultValue: 500)
            }, constraints: table =>
            {
                table.PrimaryKey("PK_Categories", x => x.CategoryID);
                table.ForeignKey("FK_Categories_Events_EventID", x => x.EventID, "Events", "EventID", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "Enrolments",
            columns: table => new
            {
                EnrolmentID = table.Column<int>(type: "int", nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                ParticipantID = table.Column<int>(type: "int", nullable: false),
                EventID = table.Column<int>(type: "int", nullable: false),
                CategoryID = table.Column<int>(type: "int", nullable: false),
                EnrolmentDate = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(GETDATE())"),
                Status = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false, defaultValue: "Confirmed")
            }, constraints: table =>
            {
                table.PrimaryKey("PK_Enrolments", x => x.EnrolmentID);
                table.CheckConstraint("CK_Enrolments_Status", "[Status] IN ('Pending','Confirmed','Cancelled')");
                table.ForeignKey("FK_Enrolments_Categories_CategoryID", x => x.CategoryID, "Categories", "CategoryID", onDelete: ReferentialAction.Restrict);
                table.ForeignKey("FK_Enrolments_Events_EventID", x => x.EventID, "Events", "EventID", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_Enrolments_Users_ParticipantID", x => x.ParticipantID, "Users", "UserID", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "Results",
            columns: table => new
            {
                ResultID = table.Column<int>(type: "int", nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                EnrolmentID = table.Column<int>(type: "int", nullable: false),
                FinishTime = table.Column<TimeSpan>(type: "time", nullable: true),
                FinishPosition = table.Column<int>(type: "int", nullable: true),
                CapturedByOrganiserID = table.Column<int>(type: "int", nullable: false),
                CapturedDate = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(GETDATE())")
            }, constraints: table =>
            {
                table.PrimaryKey("PK_Results", x => x.ResultID);
                table.ForeignKey("FK_Results_Enrolments_EnrolmentID", x => x.EnrolmentID, "Enrolments", "EnrolmentID", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_Results_Users_CapturedByOrganiserID", x => x.CapturedByOrganiserID, "Users", "UserID", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "Payments",
            columns: table => new
            {
                PaymentID = table.Column<int>(type: "int", nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                EnrolmentID = table.Column<int>(type: "int", nullable: false),
                Amount = table.Column<decimal>(type: "decimal(8,2)", precision: 8, scale: 2, nullable: false),
                PaymentDate = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(GETDATE())"),
                PaymentMethod = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false),
                PaymentStatus = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false, defaultValue: "Paid")
            }, constraints: table =>
            {
                table.PrimaryKey("PK_Payments", x => x.PaymentID);
                table.CheckConstraint("CK_Payments_Method", "[PaymentMethod] IN ('Card','EFT','InstantEFT')");
                table.CheckConstraint("CK_Payments_Status", "[PaymentStatus] IN ('Pending','Paid','Refunded')");
                table.ForeignKey("FK_Payments_Enrolments_EnrolmentID", x => x.EnrolmentID, "Enrolments", "EnrolmentID", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateIndex(name: "IX_Events_OrganiserID", table: "Events", column: "OrganiserID");
        migrationBuilder.CreateIndex(name: "IX_Categories_EventID", table: "Categories", column: "EventID");
        migrationBuilder.CreateIndex(name: "IX_Enrolments_CategoryID", table: "Enrolments", column: "CategoryID");
        migrationBuilder.CreateIndex(name: "IX_Enrolments_EventID", table: "Enrolments", column: "EventID");
        migrationBuilder.CreateIndex(name: "UQ_Enrolments_Participant_Event", table: "Enrolments", columns: new[] { "ParticipantID", "EventID" }, unique: true);
        migrationBuilder.CreateIndex(name: "IX_Results_CapturedByOrganiserID", table: "Results", column: "CapturedByOrganiserID");
        migrationBuilder.CreateIndex(name: "UQ_Results_Enrolment", table: "Results", column: "EnrolmentID", unique: true);
        migrationBuilder.CreateIndex(name: "UQ_Payments_Enrolment", table: "Payments", column: "EnrolmentID", unique: true);
        migrationBuilder.CreateIndex(name: "UQ_Users_Email", table: "Users", column: "Email", unique: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "Payments");
        migrationBuilder.DropTable(name: "Results");
        migrationBuilder.DropTable(name: "Enrolments");
        migrationBuilder.DropTable(name: "Categories");
        migrationBuilder.DropTable(name: "Events");
        migrationBuilder.DropTable(name: "Users");
    }
}
